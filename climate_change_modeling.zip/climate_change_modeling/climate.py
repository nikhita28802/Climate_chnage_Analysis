from flask import Flask, render_template, request
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor
import joblib 

# Initialize Flask app
app = Flask(__name__)

# Load your trained model and scaler
rf_model = joblib.load('model/random_forest_model.pkl')  # Load your trained Random Forest model
scaler = joblib.load('model/scaler.pkl')  # Load your trained StandardScaler


@app.route('/')
def home():
    return render_template('input.html')

@app.route('/predict', methods=['POST'])
def predict():
    # Get user input from form
    input_data = [float(x) for x in request.form.values()]

    
    # Standardize and reshape input for model
    input_scaled = scaler.transform([input_data])
    
    # Predict using Random Forest model
    prediction = rf_model.predict(input_scaled)
    
    return render_template('result.html', prediction=prediction)

if __name__ == "__main__":
    app.run(debug=True)

