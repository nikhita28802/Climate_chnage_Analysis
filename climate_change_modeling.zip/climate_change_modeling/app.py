from flask import Flask, render_template, request
import joblib
import numpy as np

app = Flask(__name__)

# Load the model
model = joblib.load('model/model.pkl')

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        likes_count_input = request.form['likesCount']
        try:
            # Ensure the input is a float
            likes_count = float(likes_count_input)
            prediction = model.predict(np.array([[likes_count]]))[0]
            return render_template('index.html', prediction=prediction, likes_count=likes_count)
        except ValueError:
            # Handle non-numeric input
            return render_template('index.html', prediction="Invalid input. Please enter a numeric value.", likes_count=None)
    return render_template('index.html', prediction=None, likes_count=None)

if __name__ == '__main__':
    app.run(debug=True)


